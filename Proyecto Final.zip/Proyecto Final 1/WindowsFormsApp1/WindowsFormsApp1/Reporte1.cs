﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace WindowsFormsApp1
{
    public partial class Reporte1 : Form
    {

        private ConexionDB conexionDB = new ConexionDB();
        public Reporte1()
        {
            InitializeComponent();
            LibrosReservados();
        }

        private void LibrosReservados()
        {
            string query = "SELECT L.ISBN, L.Titulo, L.Autor, L.Genero, COUNT(R.ISBN) AS TotalReservas FROM Libros L JOIN Reservas R ON L.ISBN = R.ISBN GROUP BY L.ISBN, L.Titulo, L.Autor, L.Genero ORDER BY TotalReservas DESC";

            using (SqlConnection conn = conexionDB.Conectar())
            {
                SqlCommand cmd = new SqlCommand(query, conn);                
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                da.Fill(dt);

                dataGridView1.DataSource = dt;
            }
        }

        private void Reporte1_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
