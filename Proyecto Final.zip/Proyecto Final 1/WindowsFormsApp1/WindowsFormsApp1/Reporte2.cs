﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace WindowsFormsApp1
{
    public partial class Reporte2 : Form
    {

        private ConexionDB conexionDB = new ConexionDB();

        public Reporte2()
        {
            InitializeComponent();
            ClientessReservados();
        }

        private void ClientessReservados()
        {
            string query = "SELECT C.IDCliente, C.Nombre, C.Apellido, C.Email FROM Cliente C JOIN Reservas R on C.IDCliente = R.IDCliente GROUP BY C.IDCliente, C.Nombre, C.Apellido, C.Email ORDER BY COUNT(R.IDCliente) DESC";

            using (SqlConnection conn = conexionDB.Conectar())
            {
                SqlCommand cmd = new SqlCommand(query, conn);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                da.Fill(dt);

                dataGridView1.DataSource = dt;
            }
        }

        private void Reporte2_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
