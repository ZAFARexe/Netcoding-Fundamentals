﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class FormLibros : Form
    {
        private ConexionDB conexionDB = new ConexionDB();
        public FormLibros()
        {
            InitializeComponent();
            MostrarTabla();
        }

        private void MostrarTabla()
        {
            string query = "SELECT * FROM Libros";

            using (SqlConnection conn = conexionDB.Conectar())
            {
                SqlCommand cmd = new SqlCommand(query, conn);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                da.Fill(dt);                           
                dataGridView1.DataSource = dt;
            }
        }

        private void FormLibros_Load(object sender, EventArgs e)
        {

        }

        private void Boton_agregar_Click(object sender, EventArgs e)
        {
            string query = "Insert Into Libros (ISBN, Titulo, Autor, Editorial, AñoPublicacion, Genero, NumeroCopias) values (@ISBN, @Titulo, @Autor, @Editorial, @AñoPublicacion, @Genero, @NumeroCopias)";

            using (SqlConnection conn = conexionDB.Conectar())
            {
                
                try
                {
                    SqlCommand cmd = new SqlCommand(query, conn);
                    cmd.Parameters.AddWithValue("@ISBN", textBox7.Text);
                    cmd.Parameters.AddWithValue("@Titulo", textBox6.Text);
                    cmd.Parameters.AddWithValue("@Autor", textBox3.Text);
                    cmd.Parameters.AddWithValue("@Editorial", textBox5.Text);
                    cmd.Parameters.AddWithValue("@AñoPublicacion", int.Parse(textBox2.Text));
                    cmd.Parameters.AddWithValue("@Genero", textBox4.Text);
                    cmd.Parameters.AddWithValue("@NumeroCopias", int.Parse(textBox1.Text));

                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Libro agregado exitosamente");
                    MostrarTabla();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error al agregar el libro: " + ex.Message);
                }
            }
        }
        private void Boton_Actualizar_Click(object sender, EventArgs e)
        {
            string query = "UPDATE Libros SET Titulo = @Titulo, Autor = @Autor, Editorial = @Editorial, AñoPublicacion = @AñoPublicacion, Genero = @Genero, NumeroCopias = @NumeroCopias where ISBN = @ISBN";

            using (SqlConnection conn = conexionDB.Conectar())
            {
                
                try
                {
                    SqlCommand cmd = new SqlCommand(query, conn);
                    cmd.Parameters.AddWithValue("@ISBN", textBox7.Text);
                    cmd.Parameters.AddWithValue("@Titulo", textBox6.Text);
                    cmd.Parameters.AddWithValue("@Autor", textBox3.Text);
                    cmd.Parameters.AddWithValue("@Editorial", textBox5.Text);
                    cmd.Parameters.AddWithValue("@AñoPublicacion", int.Parse(textBox2.Text));
                    cmd.Parameters.AddWithValue("@Genero", textBox4.Text);
                    cmd.Parameters.AddWithValue("@NumeroCopias", int.Parse(textBox1.Text));

                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Libro actualizado correctamente");
                    MostrarTabla();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error al actualizar el libro: " + ex.Message);
                }
            }
        }
        private void Boton_eliminar_Click(object sender, EventArgs e)
        {
            string query = "DELETE FROM Libros WHERE ISBN = @ISBN";

            using (SqlConnection conn = conexionDB.Conectar())
            {
                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@ISBN", textBox7.Text);

                try
                {
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Libro eliminado correctamente");
                    MostrarTabla();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error al eliminar el libro: " + ex.Message);
                }
            }
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = dataGridView1.Rows[e.RowIndex];

                textBox7.Text = row.Cells["ISBN"].Value.ToString();
                textBox6.Text = row.Cells["Titulo"].Value.ToString();
                textBox3.Text = row.Cells["Autor"].Value.ToString();
                textBox5.Text = row.Cells["Editorial"].Value.ToString();
                textBox2.Text = row.Cells["AñoPublicacion"].Value.ToString();
                textBox4.Text = row.Cells["Genero"].Value.ToString();
                textBox1.Text = row.Cells["NumeroCopias"].Value.ToString();
            }
        }

        private void Boton_salir_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
