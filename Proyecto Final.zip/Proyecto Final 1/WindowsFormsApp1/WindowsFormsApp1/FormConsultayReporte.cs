﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class FormConsultayReporte : Form
    {

        private ConexionDB conexionDB = new ConexionDB();
        public FormConsultayReporte()
        {
            InitializeComponent();
            Libros();
            Mostrar();
            
        }

        private void Libros()
        {
            string query = "SELECT distinct Genero FROM Libros";

            using (SqlConnection conn = conexionDB.Conectar())
            {
                try
                {
                    SqlDataAdapter da = new SqlDataAdapter(query, conn);
                    DataTable dt = new DataTable();
                    da.Fill(dt);

                    comboBox1.DataSource = dt;
                    comboBox1.DisplayMember = "Genero";
                    comboBox1.ValueMember = "Genero";
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error al cargar libros: " + ex.Message);
                }
            }
        }


        private void Mostrar() 
        {
            string query = "select * from Libros where Genero = @Genero and NumeroCopias>0 ";

            using (SqlConnection conn = conexionDB.Conectar())
            {
                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@Genero", comboBox1.SelectedValue);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                da.Fill(dt);

                dataGridView1.DataSource = dt;
                try
                {
                    
                }
                catch (Exception)
                {
                    MessageBox.Show("Primero debe existir libros y clientes: ");
                }
            }
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void FormConsultayReporte_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Reporte1 formReporte1 = new Reporte1();
            formReporte1.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Reporte2 formReporte2 = new Reporte2();
            formReporte2.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            Mostrar();
        }
    }
}
