﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace WindowsFormsApp1
{
    public partial class FormCliente : Form
    {

        private ConexionDB conexionDB = new ConexionDB();
        public FormCliente()
        {
            InitializeComponent();
            MostrarTabla();
        }

        private void MostrarTabla()
        {
            string query = "SELECT * FROM Cliente";

            using (SqlConnection conn = conexionDB.Conectar())
            {
                SqlCommand cmd = new SqlCommand(query, conn);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                da.Fill(dt);
                dataGridView1.DataSource = dt;
            }
        }

        private void FormCliente_Load(object sender, EventArgs e)
        {

        }

        private void Boton_agregar_Click(object sender, EventArgs e)
        {
            string query = "INSERT INTO Cliente (Nombre, Apellido, Email, Telefono) VALUES (@Nombre, @Apellido, @Email, @Telefono)";

            using (SqlConnection conn = conexionDB.Conectar())
            {
                
                try
                {
                    SqlCommand cmd = new SqlCommand(query, conn);
                    cmd.Parameters.AddWithValue("@Nombre", textBox5.Text);
                    cmd.Parameters.AddWithValue("@Apellido", textBox2.Text);
                    cmd.Parameters.AddWithValue("@Email", textBox4.Text);
                    cmd.Parameters.AddWithValue("@Telefono", textBox1.Text);

                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Usuario agregado correctamente");
                    MostrarTabla();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error al agregar el usuario: " + ex.Message);
                }
            }
        }
        string ID;
        private void Boton_eliminar_Click(object sender, EventArgs e)
        {
            string query = "DELETE FROM Cliente WHERE IDCliente = @IDCliente";

            using (SqlConnection conn = conexionDB.Conectar())
            {
                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@IDCliente", ID);

                try
                {
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Usuario eliminado correctamente");
                    MostrarTabla();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error al eliminar usuario: " + ex.Message);
                }
            }
        }



        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = dataGridView1.Rows[e.RowIndex];

                ID = row.Cells[0].Value.ToString();
                textBox5.Text = row.Cells[1].Value.ToString();
                textBox2.Text = row.Cells[2].Value.ToString();
                textBox4.Text = row.Cells[3].Value.ToString();
                textBox1.Text = row.Cells[4].Value.ToString();
            }
        }

        private void Boton_Actualizar_Click(object sender, EventArgs e)
        {
            string query = "UPDATE Cliente SET Nombre = @Nombre, Apellido = @Apellido, Email = @Email, Telefono = @Telefono WHERE IDCliente = @IDCliente";

            using (SqlConnection conn = conexionDB.Conectar())
            {
            

                try
                {
                    SqlCommand cmd = new SqlCommand(query, conn);
                    cmd.Parameters.AddWithValue("@IDCliente", ID);
                    cmd.Parameters.AddWithValue("@Nombre", textBox5.Text);
                    cmd.Parameters.AddWithValue("@Apellido", textBox2.Text);
                    cmd.Parameters.AddWithValue("@Email", textBox4.Text);
                    cmd.Parameters.AddWithValue("@Telefono", textBox1.Text);

                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Libro actualizado correctamente");
                    MostrarTabla();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error al actualizar el libro: " + ex.Message);
                }
            }
        }

        private void Boton_salir_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
