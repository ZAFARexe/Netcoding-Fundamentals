﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Boton_Libros_Click(object sender, EventArgs e)
        {
            FormLibros formLibros = new FormLibros();
            formLibros.Show();
        }

        private void Boton_Clientes_Click(object sender, EventArgs e)
        {
            FormCliente formCliente = new FormCliente();
            formCliente.Show();
        }

        private void Boton_Reserva_Click(object sender, EventArgs e)
        {
            FormReserva formReserva = new FormReserva();
            formReserva.Show();
        }

        private void Boton_Consultas_Click(object sender, EventArgs e)
        {
            FormConsultayReporte formConsultayReporte = new FormConsultayReporte();
            formConsultayReporte.Show();
        }

        private void Boton_Cierre_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}
