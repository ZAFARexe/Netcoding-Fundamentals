﻿namespace WindowsFormsApp1
{
    partial class Form1
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.Boton_Libros = new System.Windows.Forms.Button();
            this.Boton_Clientes = new System.Windows.Forms.Button();
            this.Boton_Reserva = new System.Windows.Forms.Button();
            this.Boton_Consultas = new System.Windows.Forms.Button();
            this.Boton_Cierre = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(12, 59);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(364, 207);
            this.label1.TabIndex = 0;
            this.label1.Text = "Gestión de \r\nReservas de\r\nBiblioteca";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Boton_Libros
            // 
            this.Boton_Libros.BackColor = System.Drawing.Color.Green;
            this.Boton_Libros.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.Boton_Libros.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Boton_Libros.Location = new System.Drawing.Point(534, 12);
            this.Boton_Libros.Name = "Boton_Libros";
            this.Boton_Libros.Size = new System.Drawing.Size(221, 86);
            this.Boton_Libros.TabIndex = 1;
            this.Boton_Libros.Text = "Libros";
            this.Boton_Libros.UseVisualStyleBackColor = false;
            this.Boton_Libros.Click += new System.EventHandler(this.Boton_Libros_Click);
            // 
            // Boton_Clientes
            // 
            this.Boton_Clientes.BackColor = System.Drawing.Color.Brown;
            this.Boton_Clientes.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Boton_Clientes.Location = new System.Drawing.Point(534, 124);
            this.Boton_Clientes.Name = "Boton_Clientes";
            this.Boton_Clientes.Size = new System.Drawing.Size(221, 86);
            this.Boton_Clientes.TabIndex = 2;
            this.Boton_Clientes.Text = "Clientes";
            this.Boton_Clientes.UseVisualStyleBackColor = false;
            this.Boton_Clientes.Click += new System.EventHandler(this.Boton_Clientes_Click);
            // 
            // Boton_Reserva
            // 
            this.Boton_Reserva.BackColor = System.Drawing.Color.IndianRed;
            this.Boton_Reserva.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Boton_Reserva.Location = new System.Drawing.Point(534, 238);
            this.Boton_Reserva.Name = "Boton_Reserva";
            this.Boton_Reserva.Size = new System.Drawing.Size(221, 86);
            this.Boton_Reserva.TabIndex = 3;
            this.Boton_Reserva.Text = "Reservas";
            this.Boton_Reserva.UseVisualStyleBackColor = false;
            this.Boton_Reserva.Click += new System.EventHandler(this.Boton_Reserva_Click);
            // 
            // Boton_Consultas
            // 
            this.Boton_Consultas.BackColor = System.Drawing.Color.OliveDrab;
            this.Boton_Consultas.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Boton_Consultas.Location = new System.Drawing.Point(534, 352);
            this.Boton_Consultas.Name = "Boton_Consultas";
            this.Boton_Consultas.Size = new System.Drawing.Size(221, 86);
            this.Boton_Consultas.TabIndex = 4;
            this.Boton_Consultas.Text = "Consultar y Reportes";
            this.Boton_Consultas.UseVisualStyleBackColor = false;
            this.Boton_Consultas.Click += new System.EventHandler(this.Boton_Consultas_Click);
            // 
            // Boton_Cierre
            // 
            this.Boton_Cierre.BackColor = System.Drawing.SystemColors.Info;
            this.Boton_Cierre.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Boton_Cierre.Location = new System.Drawing.Point(98, 298);
            this.Boton_Cierre.Name = "Boton_Cierre";
            this.Boton_Cierre.Size = new System.Drawing.Size(178, 47);
            this.Boton_Cierre.TabIndex = 5;
            this.Boton_Cierre.Text = "Cerrar Programa";
            this.Boton_Cierre.UseVisualStyleBackColor = false;
            this.Boton_Cierre.Click += new System.EventHandler(this.Boton_Cierre_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBox1.Image = global::WindowsFormsApp1.Properties.Resources.photo_1521587760476_6c12a4b040da;
            this.pictureBox1.Location = new System.Drawing.Point(0, 0);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(800, 450);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 6;
            this.pictureBox1.TabStop = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.Boton_Cierre);
            this.Controls.Add(this.Boton_Consultas);
            this.Controls.Add(this.Boton_Reserva);
            this.Controls.Add(this.Boton_Clientes);
            this.Controls.Add(this.Boton_Libros);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.pictureBox1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button Boton_Libros;
        private System.Windows.Forms.Button Boton_Clientes;
        private System.Windows.Forms.Button Boton_Reserva;
        private System.Windows.Forms.Button Boton_Consultas;
        private System.Windows.Forms.Button Boton_Cierre;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}

