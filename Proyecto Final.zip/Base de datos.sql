-- Ejecutar La creacion de la base de dato aparte.
Create database BiblioProyect;
-- Ejecutar todo los demas.
Use  BiblioProyect;

CREATE TABLE Libros (
    ISBN CHAR(13) PRIMARY KEY,
    Titulo NVARCHAR(255) NOT NULL,
    Autor NVARCHAR(255) NOT NULL,
    Editorial NVARCHAR(255),
    A�oPublicacion INT,
    Genero NVARCHAR(100),
    NumeroCopias INT DEFAULT 1
);

CREATE TABLE Cliente (
    IDCliente INT PRIMARY KEY IDENTITY(1,1),
    Nombre NVARCHAR(100) NOT NULL,
    Apellido NVARCHAR(100) NOT NULL,
    Email NVARCHAR(255) UNIQUE NOT NULL,
    Telefono NVARCHAR(15)
);

CREATE TABLE Reservas (
    IDReserva INT PRIMARY KEY IDENTITY(1,1), 
    IDCliente INT NOT NULL,
    ISBN CHAR(13) NOT NULL,
    FechaReserva DATE NOT NULL,
    FechaRetorno DATE NOT NULL,

    CONSTRAINT FK_Reserva_Cliente FOREIGN KEY (IDCliente)
        REFERENCES Cliente(IDCliente) ON DELETE CASCADE, 
    CONSTRAINT FK_Reserva_Libro FOREIGN KEY (ISBN)
        REFERENCES Libros(ISBN) ON DELETE CASCADE
);


INSERT INTO Libros (ISBN, Titulo, Autor, Editorial, A�oPublicacion, Genero, NumeroCopias)
VALUES ('9783161484100', 'Cien A�os de Soledad', 'Gabriel Garc�a M�rquez', 'Sudamericana', 1967, 'Novela', 5);

INSERT INTO Libros (ISBN, Titulo, Autor, Editorial, A�oPublicacion, Genero, NumeroCopias)
VALUES ('9780439139595', 'Harry Potter y el Prisionero de Azkaban', 'J.K. Rowling', 'Bloomsbury', 1999, 'Fantas�a', 10);

INSERT INTO Libros (ISBN, Titulo, Autor, Editorial, A�oPublicacion, Genero, NumeroCopias)
VALUES ('9780451524935', '1984', 'George Orwell', 'Secker & Warburg', 1949, 'Ciencia Ficci�n', 7);

INSERT INTO Cliente (Nombre, Apellido, Email, Telefono)
VALUES ('Juan', 'P�rez', 'juan.perez@gmail.com', '555-1234567');

INSERT INTO Cliente (Nombre, Apellido, Email, Telefono)
VALUES ('Mar�a', 'G�mez', 'maria.gomez@hotmail.com', '555-7654321');

INSERT INTO Cliente (Nombre, Apellido, Email, Telefono)
VALUES ('Pedro', 'Ram�rez', 'pedro.ramirez@yahoo.com', '555-1112222');


INSERT INTO Reservas (IDCliente, ISBN, FechaReserva, FechaRetorno)
VALUES (1, '9783161484100', '2024-10-01', '2024-10-15');

INSERT INTO Reservas (IDCliente, ISBN, FechaReserva, FechaRetorno)
VALUES (2, '9780439139595', '2024-10-03', '2024-10-17');

INSERT INTO Reservas (IDCliente, ISBN, FechaReserva, FechaRetorno)
VALUES (3, '9780451524935', '2024-10-05', '2024-10-19');
